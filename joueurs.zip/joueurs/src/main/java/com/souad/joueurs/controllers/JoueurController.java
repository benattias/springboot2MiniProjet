package com.souad.joueurs.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.souad.joueurs.entities.Joueur;
import com.souad.joueurs.service.JoueurService;
@Controller
public class JoueurController {
@Autowired
JoueurService joueurService;
@RequestMapping("/showCreate")
public String showCreate(ModelMap modelMap)
{
modelMap.addAttribute("joueur", new Joueur());
modelMap.addAttribute("mode", "new");
return "formJoueur";
}
@RequestMapping("/saveJoueur")
public String saveJoueur(@Valid Joueur joueur,BindingResult bindingResult)
{
if (bindingResult.hasErrors()) return "formJoueur";

joueurService.saveJoueur(joueur);
return "formJoueur";
}



@RequestMapping("/supprimerJoueur")
public String supprimerJoueur(@RequestParam("id") Long id,
ModelMap modelMap,
@RequestParam (name="page",defaultValue = "0") int page,
@RequestParam (name="size", defaultValue = "2") int size)
{
joueurService.deleteJoueurById(id);
Page<Joueur> js = joueurService.getAllJoueursParPage(page,size);
modelMap.addAttribute("produits", js);
modelMap.addAttribute("pages", new int[js.getTotalPages()]);
modelMap.addAttribute("currentPage", page);
modelMap.addAttribute("size", size);
return "listeJoueurs";
}
@RequestMapping("/modifierJoueur")
public String editerJoueur(@RequestParam("id") Long id,ModelMap modelMap)
{
	Joueur j= joueurService.getJoueur(id);
modelMap.addAttribute("joueur", j);
modelMap.addAttribute("mode", "edit");
return "editerJoueur";
}
@RequestMapping("/updateJoueur")
public String updateJoueur(@ModelAttribute("joueur") Joueur j,
@RequestParam("date") String date,

 ModelMap modelMap) throws ParseException
{
//conversion de la date
 SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
 Date dateNaissance = dateformat.parse(String.valueOf(date));
 j.setDateNaissance(dateNaissance);

 joueurService.updateJoueur(j);
 List<Joueur> js = joueurService.getAllJoueurs();
 modelMap.addAttribute("joueurs", js);
return "listeJoueurs";
}

@RequestMapping("/ListeJoueurs")
public String listeJoueurs(ModelMap modelMap,
@RequestParam (name="page",defaultValue = "0") int page,
@RequestParam (name="size", defaultValue = "2") int size)
{
Page<Joueur> jou = joueurService.getAllJoueursParPage(page, size);
modelMap.addAttribute("joueurs", jou);
modelMap.addAttribute("pages", new int[jou.getTotalPages()]);
modelMap.addAttribute("currentPage", page);
return "listeJoueurs";
}
}